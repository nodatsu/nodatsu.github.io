void T1(){
  
  textSize(18); 
  fill(0);
  text("  どれを選ぶ？\n　　１．黒髪ロング\n　　２．銀髪留学生\n　　３．金髪ツインテ",20,380,580,300);
  
 if(key=='1'){
   textNum = 2;
 }
 
 if(key=='2'){
   scene = 1;
 }
  if(key=='3'){
   scene = 1;
 }
}
 
