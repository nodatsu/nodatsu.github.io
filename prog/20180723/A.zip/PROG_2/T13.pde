void T13() {
  
  background(255);
  textSize(18);
  text("黒「そ、じゃあ、私食べ終わったから先に行くね。」\n返答を選べ\n    １．じゃあ、放課後にな。\n    ２．わかった。また後で。\n    ３．う、うん。了解。",20,380,580,300);
  
  if(key=='1'){
    textNum = 14;
  }
   if(key=='2'){
    textNum = 14;
  }
  if(key=='3'){
    textNum = 14;
  }
}
