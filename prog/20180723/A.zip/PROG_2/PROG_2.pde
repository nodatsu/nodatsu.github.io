int text;
PFont font;
int scene;
int textNum;
int quizNum;
boolean released;

void setup() {
  size(600,600);
  background(255);
  scene = 0;
 textNum = 1;
 quizNum = 1;
   font = createFont("メイリオ", 24);
   textFont(font);
}

void draw(){
  switch(scene){
    case 0:
    playing();
    break;
    case 1:
    end();
  }
}
