void T19(){
  
  background(255);
  textSize(23);
  text("ラノベゲーを作る際は結局ご都合主義は必要でした。",18,320,580,300);
  
}
