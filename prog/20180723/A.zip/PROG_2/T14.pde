void T14(){
  
  background(255);
  textSize(18);
  text("～放課後～\n選べ\n　　4．なあ、一緒に部活いかない？\n　　5．先部活いってるぞ\n　　6．また明日な",20,380,580,300);
  
  if(key=='4'){
    textNum = 16;
  }
  if(key=='5'){
    textNum = 16;
  }
  if(key=='6'){
    textNum = 15;
  }
}
