void end(){
  
   background(255);
  textSize(75); 
  fill(0);
  text("現実を見よう",20,250,580,300);
}
