 void playing() {
 
     switch(textNum){
   case 1:
   T1();
   break;
   case 2:
   T2() ;
   break;
   case 3:
   T3() ;
   break;
   case 4:
   T4();
   break;
   case 5:
   T5() ;
   break;
   case 6:
   T6();
   break;
   case 7:
   T7();
   break;
   case 8:
   T8();
   break;
   case 9:
   T9();
   break;
   case 10:
   T10();
   break;
   case 11:
   T11();
   break;
   case 12:
   T12();
   break;
   case 13:
   T13();
   break;
   case 14:
   T14();
   break;
   case 15:
   T15();
   break;
   case 16:
   T16();
   break;
   case 17:
   T17();
   break;
   case 18:
   T18();
   break;
   case 19:
   T19();
   break;
   
     }
     
 }
 void mousePressed() {
  textNum += 1;
}
