void result() {
  println("aa");
  text("GAME OVER",470,100);
  fill(255,255,255);
  if(keyPressed){
    
      gameStatus=1;
    
  }
 
}