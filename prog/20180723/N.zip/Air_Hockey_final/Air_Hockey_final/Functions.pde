void graphics() {
    // 背景の描画
    background(255);
    fill(255,0,55);
    image(img, 0, 0);
    ellipse(0,height/2,height/3,height/3); //1Pゴールの明示
    fill(0,255,65);
    ellipse(width,height/2,height/3,height/3); //2Pゴールの明示 
  
    //パックの描画
    rectMode(CENTER); //長方形を真ん中基準に
    fill(255,0,55); //1Pは赤っぽく
    rect(redX,redY,20,60);
    fill(0,255,65); //2Pは青っぽく
    rect(blueX,blueY,20,60);  //各プレイヤーの大きさは縦80、横20
    ellipseMode(CENTER);
    fill(255,255,0); //パックの色
    ellipse(puckX,puckY,20,20); //パックの描画
    
     //点数の表示
    textAlign(CENTER,CENTER);
    textSize(60);
    fill(0,255,65);  //2Pの色
    text(redPt,width/2+150,height/2);
    fill(255,0,55);  //1Pの色
    text(bluePt,width/2-150,height/2);
    
}

void refrection() {
    //跳ね返り
    //壁
    if (puckX<10) {
      puckXdirection =puckXdirection * -1;
    }
     if (puckX>950) {
      puckXdirection =puckXdirection * -1;

    }
    if (puckY<10) {
      puckYdirection =puckYdirection * -1;
    }
     if (puckY>530) {
      puckYdirection =puckYdirection * -1;
    }
    //プレイヤー
    //内側の当たり判定
    if (puckX<redX+20 && puckY<redY+30 && puckY>redY-30) {
      puckXdirection =puckXdirection * -1;
    }
    if (puckX>blueX+20 && puckY<blueY+30 &&puckY>blueY-30) {
      puckXdirection =puckXdirection * -1;
    }  
    //外側の当たり判定
   if (puckX<redX-20 && puckY<redY+30 && puckY>redY-30) {
      puckXdirection =puckXdirection * -1;
    }
    if (puckX>blueX-20 && puckY<blueY+30 &&puckY>blueY-30) {
      puckXdirection =puckXdirection * -1;
    }  
    
    
}