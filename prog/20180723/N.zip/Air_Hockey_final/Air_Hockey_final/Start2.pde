//プレイ時間選択画面

void start2() {
  background(0); //背景黒(仮設)
  fill(255); //文字白
  textAlign(CENTER,CENTER); //文字を中央ぞろえ
  textSize(30); //文字サイズ30
  
  //テキスト
  text("Press number key to choose maximum point",width/2,height/4*1); //マッチポイントを選んでください
  text("1:3pt",width/2,height/2); // 1キーで3分ゲーム
  text("2:5pt",width/2,height/2+50); // 1キーで3分ゲーム
  text("3:7pt",width/2,height/2+100); // 1キーで3分ゲーム
  
  if (keyPressed) {
    if (key=='1') {
      gameStatus=3; //1キーでゲームモードをゲームに(後で2キーの5点、3キーの7点を追加)
      gameSetup=true; //ゲームをセットアップ状態に
      maxpoint=3;
    }
    if (key=='2') {
      gameStatus=3; //1キーでゲームモードをゲームに(後で2キーの5点、3キーの7点を追加)
      gameSetup=true; //ゲームをセットアップ状態に
      maxpoint=5;
    }
    if (key=='3') {
      gameStatus=3; //1キーでゲームモードをゲームに(後で2キーの5点、3キーの7点を追加)
      gameSetup=true; //ゲームをセットアップ状態に
      maxpoint=7;
    }
    redPt=0;
    bluePt=0;
  }
}