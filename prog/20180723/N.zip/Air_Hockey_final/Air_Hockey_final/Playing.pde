//実際のゲーム画面ですの
//実装しなければならないもの一覧
//壁・パックに当たった際の反射(運動でXかYの片方の増加・減少を反転させることで実現可能です)
//得点判定(特定の壁に当たった際の挙動)
//特殊技(速度の増加、Sin関数を使った特殊な動きなどが考えられます)

//以降、特にこだわりがない限りwasd側を1P(red)、矢印キー側を2P(blue)とします

void play() {
  //この関数はgameSetupにより一度セットアップのためのコードを実行してから、ゲームに移ります
  //セットアップ状態(if gameSetup内)では、変数のリセットなどを行います。コードをすべて実行したら、gameSetup変数をfalseにしてセットアップ状態を解除して、描画に移行します。

  if (gameSetup) { //ゲームがセットアップ状態なら
    //以下ゲームのセットアップのためのコード
    background(255);  //仮の背景
    redX=width/4*1;
    redY=height/2;
    blueX=width/4*3;
    blueY=height/2;  //1,2Pの位置初期設定
    playerSpeed=12;
    puckX=width/9;
    puckY=height/4*2;  //パックの初期位置は1P寄り(2Pに飛んでいくため)
    puckXdirection=1;
    puckYdirection=1; //パックの動く方向を決定
    puckSpeed=8; //パックのスピード定義
    redPt=0;
    bluePt=0;

    gameSetup=false; //セットアップコードを完了したためセットアップ状態を解除、実際のゲーム処理、描画へ移行
    countdown=true;
    countdownTrigger=true; //カウントダウン状態へ移行、同時にカウントダウントリガーを有効化
  } else {  //ゲームのセットアップが完了したら

    //以下実際のゲームの処理
    if (countdown) { //ゲームがカウントダウン状態なら
      // 数値をいじらない描画だけの処理  
      graphics(); //背景、プレイヤーなどの描画
      if (countdownTrigger) {
        countdownTimer=millis(); //現在の時間を記録。
        countdownTrigger=false; //カウントダウントリガーを無効化。カウントダウンは続行
      } else {
        if (millis()<countdownTimer+1000) {
          fill(255);
          textSize(100);
          text('3', width/2, height/2);
        } else if (millis()>countdownTimer+1000 && millis()<countdownTimer+2000) {
          fill(255);
          textSize(100);
          text('2', width/2, height/2);
        } else if (millis()>countdownTimer+2000 && millis()<countdownTimer+3000) {
          fill(255);
          textSize(100);
          text('1', width/2, height/2);
        } else if (millis()>countdownTimer+3000) {
          countdown=false;
        }
      }




      println(puckX);
    } else { //カウントダウンが終了したら



      //操作系
      if (redUp) {
        redY-=playerSpeed;
      } 
      if (redLeft) {
        redX-=playerSpeed;
      } 
      if (redDown) {
        redY+=playerSpeed;
      } 
      if (redRight) {
        redX+=playerSpeed;
      }
      if (blueUp) {
        blueY-=playerSpeed;
      } 
      if (blueLeft) {
        blueX-=playerSpeed;
      } 
      if (blueDown) {
        blueY+=playerSpeed;
      }
      if (blueRight) {
        blueX+=playerSpeed;
      }
      //操作系のためのIf
      if (redY<30) {
        redY=30;
      } else if (redY>510) {
        redY=510;
      }
      if (blueY<30) {
        blueY=30;
      } else if (blueY>510) {
        blueY=510;
      }
      if (redX<10) {
        redX=10;
      } else if (redX>950) {
        redX=950;
      }
      if (blueX<10) {
        blueX=10;
      } else if (blueX>950) {
        blueX=950;
      }
      if (redX>460) {
        redX=460;
      }
      if (blueX<501) {
        blueX=501;
      }

      //パックの動き
      puckX+=puckSpeed * puckXdirection;
      puckY+=puckSpeed * puckYdirection;

      refrection(); //跳ね返りの挙動をまとめた関数

      //上下の当たり判定→プロダクト開発フェーズで実装

      //ゴール判定
      //ゴールは縦の中央1/3
      if (dist(puckX, puckY, 0, height/2) < height/6 + 10) {
        if (redGoal==false) {
          redPt++;
          redGoal=true;
          audio.play();
          audio.rewind();
          if (redPt==maxpoint) {
            gameStatus=4;
          }
        }
      } else {
        redGoal=false;
      }

      if (dist(puckX, puckY, width, height/2) < height/6 + 10) {
        if (blueGoal==false) {
          bluePt++;
          blueGoal=true;
          audio.play();
          audio.rewind();
          if (bluePt==maxpoint) {
            gameStatus=4;
          }
        }
      } else {
        blueGoal=false;
      }

      graphics(); //背景、プレイヤーなどの描画
    }
  }
}