void start1() { 
  background(0); //背景黒
  fill(255); //文字白
  textAlign(CENTER,CENTER); //文字を中央ぞろえ
  textSize(40); //文字サイズ40
  
  //テキスト
  text("Air Hockey",width/2,height/4*1); //X半分、Yが全体の1/4の地点にタイトルを表示
  text("Press Any Key",width/2,height/4*3); //X半分、Yが全体の4/3の地点に「何かキーを押せ」と表示
  
  //キーが押されたら選択画面1へ
  if (keyPressed) {
    gameStatus=1; 
  }
  
  
}