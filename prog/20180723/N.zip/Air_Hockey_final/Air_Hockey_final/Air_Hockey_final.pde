//メインタブ
//各関数(画面)への案内のための画面ですわ
import ddf.minim.*;  
 
Minim minim = new Minim(this); 
AudioPlayer audio;


//変数
PImage img;
int gameStatus; // ゲームの状態。0:スタート画面 1:選択画面1 2:選択画面2 3:プレイ画面 4:結果画面
int maxPt; //何点取ったら勝ちかの変数(3,5,7が入る)
int redPt;
int bluePt; //赤と青のポイント
int countdownTimer; //カウントダウンタイマーのための関数
int currentTime; //カウントダウンタイマーのための関数
boolean redGoal;
boolean blueGoal; //ゴール接触フラグ(点数の暴走防止)
boolean gameSetup; //ゲームがセットアップ状態か？falseならプレイ中
boolean countdown; //ゲームのカウントダウン
boolean countdownTrigger; //カウントダウンに入ったことを判定するフラグ
float redX;
float redY; //1PのX,Y
float blueX; 
float blueY; //2PのX,Y
float playerSpeed; //プレイヤーの速さ
float puckX;
float puckY; //パックのX,Y
int puckXdirection;
int puckYdirection; //パックのX,Y進行方向(1or-1)
float puckSpeed; //パックのスピード

boolean redUp,redLeft,redRight,redDown; //1Pのキー押しフラグ
boolean blueUp,blueLeft,blueRight,blueDown; //2Pのキー押しフラグ
int maxpoint;



//Setup関数
void setup(){
  gameStatus=0;
  size(960,540); //画面サイズ 16:9(HD画面の縮小)
  img = loadImage("truth-of-the-universe-eyecatch.jpg");
  audio=minim.loadFile( "GOALSE.mp3" );
}


//draw関数
void draw() {
  switch (gameStatus) {
    case 0:
      start1(); //スタート画面
      break;
    case 1:
      start2(); //選択画面①
      break;
    case 2:
    case 3:
      play(); //実際のゲーム画面
      break;
    case 4:  //結果、終了画面
      result();
      break;
  }
}


//キー同時押しのため操作系をこちらで定義

void keyPressed() {
  if (key=='w') {
     redUp=true;
  }
  if (key=='a') {
     redLeft=true;
  }
  if (key=='s') {
     redDown=true;
  }
  if (key=='d') {
     redRight=true;
  }
  if (keyCode==UP) {
     blueUp=true;
  }
  if (keyCode==LEFT) {
     blueLeft=true;
  }
  if (keyCode==DOWN) {
     blueDown=true;
  }
  if (keyCode==RIGHT) {
     blueRight=true;
  }
  
  
}
void keyReleased() {
    if (key=='w') {
     redUp=false;
  }
  if (key=='a') {
     redLeft=false;
  }
  if (key=='s') {
     redDown=false;
  }
  if (key=='d') {
     redRight=false;
  }
  if (keyCode==UP) {
     blueUp=false;
  }
  if (keyCode==LEFT) {
     blueLeft=false;
  }
  if (keyCode==DOWN) {
     blueDown=false;
  }
  if (keyCode==RIGHT) {
     blueRight=false;
  }
}