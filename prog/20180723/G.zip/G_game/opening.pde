PImage op;
PImage pre;
PImage title;
PImage logo;

void opening() {

  background(255);
  
  textAlign(CENTER);
  fill(0);
  
  image(title,200,100);
  image(pre,130,220);
  image(logo,480,260);

  if(keyPressed) {
    scene = 1;
  }
}