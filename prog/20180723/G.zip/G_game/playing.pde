int mx=100;
int my=280;
int i=0;
int ex=800;
int x;
int y;
int speed=5;
int speed2=10;
int life=3;
float b;
boolean a=true;
boolean jump=true;

PImage img;
PImage hard;
PImage sc;
PImage lf;
PImage j;

void playing() {
  
  player.play();
  
  background(255);
  fill(0);
  rect(0, 300, 800, 50);
  
  image(img, mx, my-45);
  image(hard, ex, 300-y);
  image(sc,450,40);
  image(lf,500,100);
  
  if (i>=4) {
    i=0;
  }
  
  
  if (a) {
    if (keyPressed && (key==' ')) {
      my-=speed;
      jump=false;
    } 
    if (my<30) {
      a=false;
    }
  }

  if (a==false&&my<280) {
    my+=speed;
    jump=true;
  }
  if (my==280) {
    a=true;
  }

  b=random(10);
  if (b<9.9) {
    if (ex>0) {
      ex-=speed2;
    }
    if (ex<=0) {
      ex=800;
      i++;
    }
    if (i==0) {
      x=70;
      y=40;
    }
    if (i==1) {
      x=30;
      y=60;
    }
    if (i==2) {
      x=40;
      y=100;
    }
    if (i==3) {
      x=40;
      y=40;
    }
  }
  
  if (score>50) {
    speed2=12;
  }
  
  if (score>100) {
    speed2=13;
  }
  
  if (score>200) {
    speed2=14;
  }

  if (my+20>300-y) {
    if (mx+90>ex&&ex>100) {
      ex=800;
      life--;
      player2.play();
      player2.rewind();
    }
  }
  
  if (my+20<300-y) {
    if (mx+90>ex&&ex>100) {
      score++;
    }
  }

  if (life==0) {
    ex=800;
    life=3;
    speed2=10;
    scene++;
  }
  
  textSize(50);
  text(score, 740, 90);
  text(life, 740, 150);
}

void keyReleased() {
  a=false;
}

void keyPressed() {
  if (jump==true) {
    player1.play();
    player1.rewind();
  }
}

void stop() {

  player.close(); 
  minim.stop();
  super.stop();
}