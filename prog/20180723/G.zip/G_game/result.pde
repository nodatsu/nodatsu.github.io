
PImage im;
PImage res;
PImage sc2;

void result(){
  
  background(255);
  
  image(im,-15,-40);
  image(res,290,175);
  image(sc2,600,0);
  
  textAlign(CENTER);
  fill(255);
  
  
  textSize(28);
  text(score,770, 30);
  
  
  if(mousePressed){
    scene = 0;
    score=0;
  } 
}