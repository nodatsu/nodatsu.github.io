import ddf.minim.*; 
 
Minim minim;  
Minim minim1;
Minim minim2; 

AudioPlayer player;
AudioPlayer player1;
AudioPlayer player2;

int scene=0;
int score;


void setup() {
  size(800, 350);
  minim = new Minim(this); 
  minim1 = new Minim(this);
  minim2 = new Minim(this);
  
  player = minim.loadFile("tyoco.mp3");
  player1 = minim.loadFile("jp.mp3");
  player2 = minim.loadFile("dm.mp3");
  
  img = loadImage("basasi.png");
  
  im=loadImage("res.png");
  
  res=loadImage("try.png");
  
  hard=loadImage("h.png");
  
  j=loadImage("jump.png");
  
  pre=loadImage("press.png");
  
  sc=loadImage("score.png");
  
  lf=loadImage("life.png");
  
  title=loadImage("title.png");
  
  logo=loadImage("logo.png");
  
  sc2=loadImage("score2.png");
  
  scene = 0;
}

void draw() {
  switch(scene) {
  case 0:
    opening();
    break;
  case 1:       
    playing();  
    break;
  case 2:       
    result();   
    break;
  }
}