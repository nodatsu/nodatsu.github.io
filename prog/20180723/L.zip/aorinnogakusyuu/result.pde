void result() {
  background(0);
  imageMode(CORNER);
  img2 = loadImage("result.JPG");
  image(img2,0,0);

}