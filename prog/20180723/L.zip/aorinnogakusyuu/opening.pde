PFont font; 

void opening() {
  img4 = loadImage("opening.jpg");
  image(img4, 0, 0, 500,700);
  fill(200, 50, 0);
  textSize(40);
  text("あおりんの逆襲", 100, 100);
  textSize(20);
  text("キー入力で次の画面へ...", 200, 650);
  if (keyPressed){
    scene = 1;
  }
}