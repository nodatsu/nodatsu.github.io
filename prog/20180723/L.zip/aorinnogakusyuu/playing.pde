int eHP =100;
float eS =100;
float eX =310;
float eY =80;

int e1HP =30;
float e1S =15;
float e1X =100;
float e1Y =130;

int e2HP =30;
float e2S =15;
float e2X =200;
float e2Y =180;

int e3HP =30;
float e3S =15;
float e3X =420;
float e3Y =150;

int pHP =30;
float pS =50;
float pX =260;
float pY =630;
float pV = 5;

float esS =10;
float esX =eX;
float esY =eY;
float esV =20;

float e1sS =10;
float e1sX =e1X;
float e1sY =e1Y;

float e2sS =10;
float e2sX =e2X;
float e2sY =e2Y;

float e3sS =10;
float e3sX =e3X;
float e3sY =e3Y;

float psS =10;
float psX =pX;
float psY =pY;
float psV = -10;

int radius =100;
float spead = 1;
int direction = 1;

boolean sL = false;
boolean esL = false;
int flag=0;

void playing() {
  img1 = loadImage("playing.JPG");
  imageMode(CORNER);
  image(img1, 0, 0);
  fill(255,0,255);  
  textSize(13);
  text("player HP =" + pHP, 10, 20);
  text("aorin HP =" + eHP, 10, 40);
  text("mini aorin1 HP =" +e1HP, 10, 60);
  text("mini aorin2 HP =" +e2HP, 10, 80);
  text("mini aorin3 HP =" +e3HP, 10, 100);
  
  imageMode(CENTER);
  
   image(img6,eX,eY);
   image(img5,e1X,e1Y);
   image(img5,e2X,e2Y);
   image(img5,e3X,e3Y);
  eX += spead*direction;
  
  if((eX>width-radius)||(eX< radius)){
    direction = -direction;
  }
  
  if(esL==false){
  fill(0,0,255);
  ellipse(esX,esY,esS,esS);
  esY += esV;
  }
  
  if(esY >700 || esL==true){
    esY=eY;
    esX=eX;
    esL=false;
  }
  
  if(esL==false){
  if(dist(pX,pY,esX,esY)<(pS + esS) / 2){
    esL=true;
    pHP -= 10;
    }
  }

  if (pHP == 0){
    scene=4;
  }
  
  fill(255);

  ellipse(pX, pY, 60, 60);

  if (keyPressed==true) {
    flag=1;
  }
  
  if (flag==1) {
    pX=mouseX;
    pY=mouseY;
  }
  
  if(sL){
  fill(255, 255, 0);
  ellipse(psX,psY,psS,psS);
  psY += psV;
  
  if(psY<0){
    sL=false;
    println("case1");
   }
  }
  
  if(sL){
  if (dist(eX, eY, psX, psY)<(eS+psS)/2) {
    eHP -= 10;
    sL =false;
    println("case2");
    
    if (eHP == 0) {
      scene=3;
    }
   }
  }
  
  if (mousePressed) {
      if (!sL) {
        psX= pX;
        psY= pY;
        sL= true;
    }
  }
}