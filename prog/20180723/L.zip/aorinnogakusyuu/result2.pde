void result2(){
  background(0);
  imageMode(CORNER);
  img3 = loadImage("result2.JPG");
  image(img3, 0, 0);
}
  