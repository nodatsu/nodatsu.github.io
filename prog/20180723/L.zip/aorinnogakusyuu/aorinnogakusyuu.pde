int scene;
PImage img1;
PImage img2;
PImage img3;
PImage img4;
PImage img5;
PImage img6;

void setup() {
  size(500, 700);
  scene=0;
  font = createFont("Font_file.ttf", 32); 
  img1 = loadImage("playing.JPG");
  img2 = loadImage("result.JPG");
  img3 = loadImage("result2.JPG");
  img4 = loadImage("opening.jpg");
  img5 = loadImage("zako.png");
  img6 = loadImage("boss.png");
  textFont(font);
  rectMode(CENTER);
}

void draw() {
  
  
  switch(scene) {
  case 0:
    opening();
    break;
  case 1:
    Description();
    break;
  case 2:
    playing();
    break;
  case 3:
    result();
    break;
  case 4:
    result2();
    break;
  default:
    exit();
  }
}