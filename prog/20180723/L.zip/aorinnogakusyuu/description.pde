void Description() {
  background(0);
  fill(255);
  textFont(font);
  textSize(20);
  text("操作方法", 40, 100);

  text("移動 :マウスカーソルを上下左右に動かす", 50, 150);
  text("攻撃 : マウスの左クリックで弾を発射", 50, 170);

  text("ルール説明", 40, 220);
  text("BIGあおりんのHPを0にしたら勝ち", 50, 240);
  text("制限時間・プレイヤーのHPが0になったら負け", 50, 260);
  textSize(25);
  fill(255, 0, 0);
  text("マウスクリックでゲームスタート!!", 50, 500);
  if (mousePressed) {
    scene = 2;
  }
}