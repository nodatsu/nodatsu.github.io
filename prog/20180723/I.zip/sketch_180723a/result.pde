void result() {
  background(0);
  fill(255);

  textSize(50);
  text("clear", 250, 250);
  textAlign(CENTER);

  if (mousePressed) {
    scene = 3;
  }
}