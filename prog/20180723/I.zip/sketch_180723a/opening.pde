
  

void opening() {
  background(0);
  image(img, 0, 0, 500, 700); 
  fill(255);
  textSize(50);
  text("<SHUTO>", 250, 280);
  textAlign(CENTER);
  textSize(30);
  text("CLICK TO START", 245, 480);
  





  
  if (mousePressed) {
    scene = 1;
  }
}