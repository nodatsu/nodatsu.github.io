int scene;
PImage img;

void setup() {
  size(500, 500);
  scene = 0;
  rectMode(CENTER);
  img = loadImage("iop.png");
  
  
}



void draw() {
  switch (scene) {
  case 0:
    opening();
    break;
  case 1:
    playing();
    break;
  case 2:
    result();
    break;
  default:
    exit();
    int timer = millis();
    println(timer);
  }
}