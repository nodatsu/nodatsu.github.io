int eN = 5;
float eS = 30;
float eX = 200;
float eY= 50;


float pS = 30;
float pX = 200;
float pY = 350;
float pV = 5;

float sS = 15;
float sX = 250;
float sY = 250;
float sV = -20;
boolean sL = false;
PImage img2;
PImage img3;
float angle =0.0;
float offset =60;
float scalar = 40;
float speed =0.1;

void playing() {
  background(0);
  image(img, 0, 0, 500, 700);
  fill(255);

  textSize(30);
  text("enemy = " + eN, 410, 40);

eY = (int)(offset + sin(angle) * scalar);
 
  rect(eX, eY, 50, 50);
  angle += speed;
  
 eX += 5;
 if (eX >= 500) {
   offset = (int)(Math.random() * (200 - 32));
   eX=-32;
 }

 
   img2 = loadImage("oop.png");
   image(img2,pX, pY,pS,pS);
  
  
   



  if (sL) {
    ellipse(sX, sY, sS, sS);
    sY += sV;
    if (sY < 0) {
      sL = false;
    }
    if (dist(eX, eY, sX, sY) < (eS + sS) / 2) {
      eN -= 1;
      sL = false;
      if (eN == 0) {
        scene = 2;
      }
    }
  }

  if (keyPressed) {
    if (key == CODED) {
      switch (keyCode) {
      case LEFT:
        pX -= pV;
        break;
      case RIGHT:
        pX += pV;
        break;
      }
    } else {
      if (!sL) {
        sX = pX;
        sY = pY;
        sL = true;
      }
    }
  }
}