float x = 270.0;

int eN = 0;

float eS = 40;
float eX = 270;
float eY = 270;
float eV = 3;

float pS = 5;
float pX = 270;
float pY = 100;
float pV = 10;

float sS =40;
float sX =270;
float sY =200;
float sV = 17;//ボールのスピード

float mX = 550;
float mY = 40;

boolean sL = false;

void playing() {
  background(0, 255, 0);
  fill(255);
  imageMode(CORNER);
  image(img2,0,0,550,700);

  text("スコア:" + eN, 100, 100);

  rect(270, 600, 350, 100);//ゴール

  ellipse(pX, pY, pS, pS);//相手
  imageMode(CENTER);
  image(img4,pX, pY, 100, 100);//相手

  ellipse(x, mX, mY, mY);//自分
  imageMode(CENTER);
  image(img3,x, mX, 42, 42);//自分
   
  if (sL) {
    ellipse(sX, sY, sS, sS);
    imageMode(CENTER);
    image(img5,sX, sY, sS, sS);
    
    sY += sV;
    if (sY > 700) {
      sL = false;
    }
    if (dist(x, mX, sX, sY)<(pS + sS)/2) {
      eN += 1;
      sL = false;
      if (eN == 5) {
        scene = 2;
      }
    }
  }
  if (keyPressed) {
    if (key == CODED) {
      switch(keyCode) {
      case LEFT:
        x -= pV;
        break;
      case RIGHT:
        x += pV;
        break;
      }
    } else {
      if (!sL) {
        sX = pX;
        sY = pY;
        sL = true;
      }
    }
  }
}