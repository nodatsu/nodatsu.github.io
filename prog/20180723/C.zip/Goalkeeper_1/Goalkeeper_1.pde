int scene;
int score;
PFont font;
boolean released;

PImage img1;
PImage img2;
PImage img3;
PImage img4;
PImage img5;
PImage img6;

void setup() {
  size(550,700);
  scene = 0;
  rectMode(CENTER);
  font = createFont("メイリオ",24);
  textFont(font);
  
  img1 = loadImage("opening.jpg");
  img2 = loadImage("サッカーコート.png");
  img3 = loadImage("kawasima2.2.png");
  img4 = loadImage("キッカー.png");
  img5 = loadImage("サッカーボール.png");
  img6 = loadImage("２川島.jpg");
}

void draw(){
  switch(scene){
    case 0:
     opening();
     break;
    case 1:
     playing();
     break;
    case 2:
     result();
     break;
    default:
     exit();
  }
   
 }
  