void opening() {
  fill(255);
  image(img1,0,0,550,700);
  textAlign(CENTER,CENTER);
  
  
  textSize(50);
  text("ゴールキーパー",280,200);
  textSize(20);
  text("キーを押してスタート",280,500);
  
  if(keyPressed) {
    scene = 1;
  }
}