void result() {
  background(0,255,0);
  fill(255,0,0);
  imageMode(CORNER);
  image(img6,0,0,550,700);
  textSize(50);
  text("スコア:"+eN,120,200);
  
  if(mousePressed){
    scene = 3;
 }
}