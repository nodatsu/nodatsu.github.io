int scene; // シーン番号
int score; // 正解数

PImage img1;
PImage img2;
PImage img3;
PImage img4;
PImage img5;
PImage img6;
PImage img7;

int radius = 40;
float speed = 4;
int direction = 1;
float x;
float y;

float pS = 60;
float pX = 320;
float pY = 450;
float pV = 5;

float bS = 60;
float bX = 320;
float bY = 500;
float bV = -7;
boolean bL = false;


void setup() { // 初期設定
  size(560,700);
  scene = 0; // シーン番号を 0 に設定
  score = 0; // 正解数を 0 に設定
  x = width/2;
  y = height/2;
  
  
 ellipseMode(RADIUS);
  img1 = loadImage("00969.jpg");
  img2 = loadImage("goalee.png");
  img3 = loadImage("soccer_ball.png");
  img4 = loadImage("BB.png");
  img5 = loadImage("a.png");
  img6 = loadImage("b.png");
  img7 = loadImage("c.png");
  ellipseMode(RADIUS);
 }
 
void draw() {
  image(img2, 280, 50, 150, 150);
  background(200);
  image(img1, -20, 0, 600, 800);
  translate(-70,0);
  image(img4, pX, pY, 160, 160);
  if(bL) {
    image(img3, bX, bY, bS, bS);
     bY += bV;
     if (bY < 0) {
       Goal += 1;
       bL = false;
     }
     if (dist(x, 50, bX, bY) < (150 + 60) /2) {
       bL =  false;
     }
  }
  fill(255);
  rect(80, 0, 540, 10);
  rect(80, 0, 10, 90);
  rect(610, 0, 10, 90);
  rect(70, 600, 560, 100);
  
  x += speed * direction;
  if((x > width-radius) || (x < radius)) {
    direction = -direction;
  }
  
  if(direction == 1) {
    image(img2, x, 50, 150, 150);
  } else {
   image(img2, x, 50, 150, 150);
  }
  

  // シーン切り替え
  switch(scene) {
  case 0: // 開始画面
    opening(); // 開始画面の表示
    break;
  case 1:
    Description();
    break;
  case 2: // プレイ画面
    playing(); // プレイ画面の表示
    break;
  case 3: // 結果画面
    result(); // 結果画面の表示
    break;
  default: // それ以外 ( デフォルトの状態 )
    break;
    case 4:
  }
}