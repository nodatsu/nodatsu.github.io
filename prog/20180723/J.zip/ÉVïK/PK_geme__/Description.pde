PFont font;

void Description() {
  background(0);
  font = createFont("Font_file.ttf",32);
  textFont(font);
  fill(200,50,0);
  textSize(40);
  text("ルール",320,115);
  textSize(25);
  text("ゴールの中にシュートを決める。",268,160);
  textSize(25);
  text("１０得点目指してがんばろう",240,210);
  textSize(25);
  text("制限時間は３０秒！",195,260);
   textSize(40);
text("操作方法",330,400);
  textSize(25);
  text("←　→　キーでプレイヤーが移動", 340, 450);
  text("キーを押すとボールをシュート",335,490);
  textSize(25);

  
 textSize(40);
  text("キーを押してゲームスタート！",355,650);
  if(keyPressed == true) {
    scene = 2;
  }
}