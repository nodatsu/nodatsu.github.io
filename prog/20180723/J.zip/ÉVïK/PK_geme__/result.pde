void result(){
  background(255);
  image(img5, 320, 410, 300, 300);
  image(img6, 40, 400, 300, 300);
  image(img7, 180, 5, 350, 350);
  fill(0);
  textSize(50);
  text("ゲーム終了！" , 350, 380);
  textSize(30);
  text("あなたのゴール数" , 330, 420);
  text(nf(Goal) , 470, 420);
  
}