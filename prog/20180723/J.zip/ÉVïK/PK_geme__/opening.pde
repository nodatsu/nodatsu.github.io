void opening() {
  // 開始画面
  background(0);
  textAlign(CENTER);
  textSize(230);
  text("PK", 200, 270);
  textSize(170);
  text("GAME", 303, 410);
  // クリックされたのを確認してプレイ画面へ移動
  if (mousePressed == true) {
    scene =  1; // シーン番号を 1 に変更
  }
}