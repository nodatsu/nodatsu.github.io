int Goal = 0;
int Time = 30;
int timeCounter = 0;

void playing(){
  fill(0);
   text("Goal = ", 160, 650);
   text(nf(Goal, 2), 250, 650);
   text("Time = ", 450,650);
   text(nf(Time, 2), 550, 650);
   
   timeCounter += 1;
   if(timeCounter%60 == 0) {
     
     Time -= 1;}
   
   if (Goal == 10) {
     scene = 3;
   }
   if (Time == 0) {
     scene = 3;
   }
   
   if (keyPressed) {
     if (key == CODED) {
       switch (keyCode) {
         case LEFT:
         pX -= pV;
         break;
         case RIGHT:
         pX += pV;
         break;
       }
     } else {
       if (!bL) {
       bX = pX;
       bY = pY;
       bL = true;
     }
     }
       
   }
}