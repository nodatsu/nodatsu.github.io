int scene;

PImage imgop;
PImage imgpl;

boolean l;//左キーが押されているフラグ
boolean r;//右キーが押されているフラグ
boolean s;//発射キーが押されているフラグ

void setup() {
  size(700, 800);
  scene = 0;
  rectMode(CENTER);
  imgop = loadImage("地球.jpg");
  imgpl = loadImage("宇宙.jpg");
}

void keyPressed(){
  if (keyCode==LEFT){
    l=true;
  }
  else if (keyCode==RIGHT){
    r=true;
  }
  else{
    s=true;
  }
}

void keyReleased(){
  if (keyCode==LEFT){
    l=false;
  }
  else if (keyCode==RIGHT){
    r=false;
  }
  else{
    s=false;
  }
}

void draw() {
  switch (scene) {
    case 0:
    opening();
    break;
    case 1:
    play1();
    break;
    case 2:
    rulu();
    break;
    case 3:
    result_win();
    break;
    case 4:
    result_loss();
    break;
    case 5:
    play2();
    break;
    case 6:
    play3();
    break;
    case 7:
    space1();
    break;
    case 8:
    space2();
    break;
    default:
    exit();
  }
}