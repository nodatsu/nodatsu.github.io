int eN2 = 3;
int pN2 = 3;
float eS2 = 30;
float eX2 = 350;
float eY2 = 100;
float eV2 = 6;

float pS2 = 30;
float pX2 = 350;
float pY2 = 700;
float pV2 = 5;

float sS2 = 15;
float sX2 = 350;
float sY2 = 300;
float sV2 = -30;
boolean sL2 = false;

float esS2 = 15;
float esX2 = 350;
float esY2 = 300;
float esV2 = 0;
int count2 = 0;
boolean esL2 = false;


void play2() {

  count2 ++;

  background(0);
  fill(255);
  image(imgpl, 0, 0, width, height);
  textSize(20);
  text("HP" + eN2, 300, 20);
  text("HP " + pN2, 300, 780);

  rect(eX2, eY2, eS2, eS2);

  rect(pX2, pY2, pS2, pS2);

  eX2+=eV2;
  if (eX2>width-eS2/2||eX2<eS2/2) {
    eV2=-eV2;
  }

  if (sL2) {
    ellipse(sX2, sY2, sS2, sS2);
    sY2 += sV2;
    if (sY2 < 0) {
      sL2 = false;
    }
    if (dist(eX2, eY2, sX2, sY2)<(eS2 + sS2) / 2) {
      eN2 -= 1;
      sL2 = false;
      if (eN2 == 0) {
        scene = 8;
        eN3 = 3;
        pN3 = 3;
      }
    }
  }

  if (l) {
    pX2-=pV2;
    if (pX2<pS2/2) {
      pX2 = pS2/2;
    }
  }
  if (r) {
    pX2+=pV2;
    if (pX2>width-pS2/2) {
      pX2 = width-pS2/2;
    }
  }
  if (s) {
    if (!sL2) {
      sX2 = pX2;
      sY2 = pY2;
      sL2 = true;
    }
  }
  if (count2>100) {
    esY2 = eY2;
    esX2 = eX2;
    esV2 = 30;
    count2 = 0;
    esL2 = true;
  }
  if (esL2) {
    ellipse(esX2, esY2, esS2, esS2);
    esY2 += esV2;
    if (dist(pX2, pY2, esX2, esY2)<(pS2 + esS2) / 2) {
      pN2 -= 1;
      esL2 = false;
      if (pN2 == 0) {
        scene = 4;
        eN3 = 3;
        pN3 = 3;
      }
    }
  }
}