void rulu() {
  background(0);
  fill(255);
  textSize(50);
  text("ルール説明",200,200);
  
    if(mousePressed){
    scene = 1;
  }
}