int eN = 3;
int pN = 3;
float eS = 30;
float eX = 350;
float eY = 100;
float eV = 5;

float pS = 30;
float pX = 350;
float pY = 700;
float pV = 5;

float sS = 15;
float sX = 350;
float sY = 300;
float sV = -30;
boolean sL = false;

float esS = 15;
float esX = 350;
float esY = 300;
float esV = 0;
int count = 0;
boolean esL = false;

void play1() {
  count++;

  background(0);
  fill(255);
  image(imgpl, 0, 0, width, height);
  textSize(20);
  text("HP " + eN, 300, 20);
  text("HP " + pN, 300, 780);

  rect(eX, eY, eS, eS);

  rect(pX, pY, pS, pS);

  eX+=eV;
  if (eX>width-eS/2||eX<eS/2) {
    eV=-eV;
  }


  if (sL) {
    ellipse(sX, sY, sS, sS);
    sY += sV;
    if (sY < 0) {
      sL = false;
    }
    if (dist(eX, eY, sX, sY)<(eS + sS) / 2) {
      eN -= 1;
      sL = false;
      if (eN == 0) {
        scene = 7;
        eN2 = 3;
        pN2 = 3;
      }
    }
  }

  if (l) {
    pX-=pV;
    if (pX<pS/2) {
      pX = pS/2;
    }
  }
  if (r) {
    pX+=pV;
    if (pX>width-pS/2) {
      pX = width-pS/2;
    }
  }
  if (s) {
    if (!sL) {
      sX = pX;
      sY = pY;
      sL = true;
    }
  }
  if (count>100) {
    esY = eY;
    esX = eX;
    esV = 10;
    count = 0;
    esL = true;
  }
  if (esL) {
    ellipse(esX, esY, esS, esS);
    esY += esV;
    if (dist(pX, pY, esX, esY)<(pS + esS) / 2) {
      pN -= 1;
      esL = false;
      if (pN == 0) {
        scene = 4;
        eN2 = 3;
        pN2 = 3;
      }
    }
  }
}