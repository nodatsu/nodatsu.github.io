void result_loss() {
  background(0);
  fill(13,47,255);
  textSize(250);
  text("LOSE",60,450);
  
  if(keyPressed){
    scene = 0;
  }
} 