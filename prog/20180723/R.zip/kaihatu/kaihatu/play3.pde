int eN3 = 3;
int pN3 = 3;
float eS3 = 30;
float eX3 = 350;
float eY3 = 100;
float eV3 = 7;

float pS3= 30;
float pX3 = 350;
float pY3 = 700;
float pV3 = 5;

float sS3 = 15;
float sX3 = 350;
float sY3 = 300;
float sV3 = -30;
boolean sL3 = false;

float esS3 = 15;
float esX3 = 350;
float esY3 = 300;
float esV3 = 0;
int count3 = 0;
boolean esL3 = false;

void play3() {

  count3 ++;

  background(0);
  fill(255);
  image(imgpl, 0, 0, width, height);
  textSize(20);
  text("HP " + eN3, 300, 20);
  text("HP " + pN3, 300, 780);

  rect(eX3, eY3, eS3, eS3);

  rect(pX3, pY3, pS3, pS3);

  eX3+=eV3;
  if (eX3>width-eS3/2||eX3<eS3/2) {
    eV3=-eV3;
  }

  if (sL3) {
    ellipse(sX3, sY3, sS3, sS3);
    sY3 += sV3;
    if (sY3 < 0) {
      sL3 = false;
    }
    if (dist(eX3, eY3, sX3, sY3)<(eS3 + sS3) / 2) {
      eN3 -= 1;
      sL3 = false;
      if (eN3 == 0) {
        scene = 3;
      }
    }
  }

  if (l) {
    pX3-=pV3;
    if (pX3<pS3/2) {
      pX3 = pS3/2;
    }
  }
  if (r) {
    pX3+=pV3;
    if (pX3>width-pS3/2) {
      pX3 = width-pS3/2;
    }
  }
  if (s) {
    if (!sL3) {
      sX3 = pX3;
      sY3 = pY3;
      sL3 = true;
    }
  }
  if (count3>50) {
    esY3 = eY3;
    esX3 = eX3;
    esV3 = 30;
    count3 = 0;
    esL3 = true;
  }
  if (esL3) {
    ellipse(esX3, esY3, esS3, esS3);
    esY3 += esV3;
    if (dist(pX3, pY3, esX3, esY3)<(pS3 + esS3) / 2) {
      pN3 -= 1;
      esL3 = false;
      if (pN3 == 0) {
        scene = 4;
      }
    }
  }
}