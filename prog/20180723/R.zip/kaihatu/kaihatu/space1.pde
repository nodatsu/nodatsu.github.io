void space1() {
  background(0);
  fill(255);
  textSize(50);
  text("Click Next…",200,350);
  
    if(mousePressed){
    scene = 5;
  }
}