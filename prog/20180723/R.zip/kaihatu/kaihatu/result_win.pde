void result_win() {
  background(0);
  fill(255,247,0);
  textSize(250);
  text("WIN",120,450);
  
  
  
  if(keyPressed){
    scene = 0;
  }
}