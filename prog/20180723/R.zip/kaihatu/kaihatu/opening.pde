void opening() {
  background(0);
  fill(255);
  image(imgop,0,0,width,height);
  textSize(100);
  text("Shooting",135,300);
  text("Game",215,400);
  
  
  if(mousePressed){
    s = false;
    scene = 1;
    eN = 3;
    pN = 3;
  }
}