class Chara {
  float px, py;
  float cs;
  PImage chip;
  int dir;  // 前:0, 左:1, 右:2, 後:3

  Chara() {
    px = 0;
    py = 0;
    cs = 100;
    chip = loadImage("chip.png");
    dir = 0;
  }

  void display() {
    beginShape();
    texture(chip);
    float ts = 32;
    float tx = 0;
    float ty = ts * dir;
    vertex(px     , py     , tx     , ty     );
    vertex(px + cs, py     , tx + ts, ty     );
    vertex(px + cs, py + cs, tx + ts, ty + ts);
    vertex(px     , py + cs, tx     , ty + ts);
    endShape();
  }
  
  void walk(int k) {
    switch (k) {
      case RIGHT:  px += cs;  dir = 2;  break;
      case LEFT:   px -= cs;  dir = 1;  break;
      case DOWN:   py += cs;  dir = 0;  break;
      case UP:     py -= cs;  dir = 3;  break;
    }
  }
}