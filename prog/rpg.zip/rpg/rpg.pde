Chara c1;

void setup() {
  size(800, 600, P3D);
  
  c1 = new Chara();
  ellipseMode(CORNER);
}

void draw() {
  background(0);
  
  c1.display();
}

void keyPressed() {
  c1.walk(keyCode);
}