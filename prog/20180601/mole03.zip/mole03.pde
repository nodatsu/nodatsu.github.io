float mx, my;
int score;
int clock;

void setup() {
  size(400, 400);
  clock = millis();
}

void draw() {
  if (millis() - clock > 2000) {
    clock = millis();
    mx = random(0, 400);
    my = random(0, 400);
  }

  background(0);
  text("score = " + score, 300, 30);

  ellipse(mx, my, 50, 50);

  if (mousePressed) {
    if (dist(mouseX, mouseY, mx, my) < 50) {
      score++;
    }
  }
}