float mx, my;
int score;

void setup() {
  size(400, 400);
}

void draw() {
  mx = 200;
  my = 200;
  
  background(0);
  text("score = " + score, 300, 30);

  ellipse(mx, my, 50, 50);

  if (mousePressed) {
    if (dist(mouseX, mouseY, mx, my) < 50) {
      score++;
    }
  }
}