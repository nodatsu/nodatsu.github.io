void result() {
  background(0);

  if (score == 3) {
    text("You Win!", 200, 200);
  }
  else {
    text("Game Over ... ", 200, 200);
  }
}