int scene;
float mx, my;
int score;
int miss;
int clock;
boolean appear;

void setup() {
  size(400, 400);
  clock = millis();
}

void draw() {
  switch (scene) {
  case 0:
    opening();
    break;
  case 1:
    playing();
    break;
  case 2:
    result();
    break;
  }
}