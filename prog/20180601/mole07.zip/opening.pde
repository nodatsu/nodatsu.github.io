void opening() {
  if (mousePressed) {
    scene++;
  }
  
  background(0);
  
  text("whack-a-mole", 200, 200);
  text("click to start", 200, 220);
}