float mx, my;
int score;
int miss;
int clock;
boolean appear;

void setup() {
  size(400, 400);
  clock = millis();
}

void draw() {
  if (score >= 3 || miss >= 3) {
    exit();
  }
  
  if (millis() - clock > 2000) {
    clock = millis();
    mx = random(0, 400);
    my = random(0, 400);
    if (appear) {
      miss++;
    }
    else {
      appear = true;
    }
  }

  background(0);
  text("score = " + score, 300, 30);
  text("miss = " + miss, 300, 50);

  if (appear) {
    ellipse(mx, my, 50, 50);

    if (mousePressed) {
      if (dist(mouseX, mouseY, mx, my) < 50) {
        score++;
        appear = false;
      }
    }
  }
}