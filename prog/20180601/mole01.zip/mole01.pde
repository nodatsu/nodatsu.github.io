void setup() {
  size(400, 400);
}

void draw() {
  background(0);
  
  ellipse(200, 200, 50, 50);

  if (mousePressed) {
    println("Hit!");
  }
}